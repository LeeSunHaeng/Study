package Test;

public class ClassTest_2 extends ClassTest_1 {
	
	private String department;
	private String name;
	private int money;
	private String position;
	


	public ClassTest_2(String name, int money, String position) {
		this.name=name;
		this.money=money;
		this.position=position;
	}
	
	public void getInformation() { 
		System.out.println("이름:" + name + " 연봉: " + money + " 부서 : " + position); 
	} 
	
	public void prn() { 
		System.out.println("서브클래스"); 
	}	
	
	public void callSuperThis() {
		super.prn();
		prn();
	}

}
