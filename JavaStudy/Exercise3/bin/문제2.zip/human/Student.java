package human;

public class Student extends Human {
	String number;
	public Student(String name, int age, int height, int weight, String number) {
		super.name = name;
		super.age = age;
		super.height = height;
		super.weight = weight;
		this.number=number;
	}
	public String toString() {
		String data = name + "\t" + age + "\t" + height + "\t" + weight +"\t" + number;
		return data;

}
}
